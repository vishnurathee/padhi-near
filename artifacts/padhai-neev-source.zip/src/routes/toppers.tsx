import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { StepArrows } from "@/components/step-arrows";
import toppers from "@/data/toppers.json";

type Mentor = {
  id: string;
  name: string;
  result: string;
  focus: string;
  intro: string;
  replies: { q: string; a: string }[];
};

const mentors = toppers as Mentor[];

export const Route = createFileRoute("/toppers")({ component: ToppersPage });

function ToppersPage() {
  const [activeId, setActiveId] = useState(mentors[0]?.id ?? "");
  const mentor = mentors.find((item) => item.id === activeId) ?? mentors[0];
  const [open, setOpen] = useState(false);
  const [asked, setAsked] = useState<string[]>([]);
  const [thread, setThread] = useState<{ from: "me" | "them"; text: string }[]>(mentor ? [{ from: "them", text: mentor.intro }] : []);

  if (!mentor) return null;

  function pick(id: string) {
    const next = mentors.find((item) => item.id === id);
    if (!next) return;
    setActiveId(id);
    setAsked([]);
    setOpen(true);
    setThread([{ from: "them", text: next.intro }]);
  }

  function ask(question: string, answer: string) {
    if (asked.includes(question)) return;
    setAsked((list) => [...list, question]);
    setThread((list) => [...list, { from: "me", text: question }, { from: "them", text: answer }]);
  }

  return (
    <main className="c10 solve-page">
      <header className="c10-bar">
        <Link to="/c/$classId" params={{ classId: "10" }} search={{ tab: "home" }} className="feature-back">
          ← Back
        </Link>
        <Link to="/" className="c10-logo">
          Padhaai <span>Neev</span>
        </Link>
        <StepArrows back="/solve" forward="/evaluate" />
        <span className="vip-badge">Class 10th VIP Portal</span>
      </header>
      <section className="vip-window">
        <Link to="/c/$classId" params={{ classId: "10" }} search={{ tab: "home" }} className="vip-back">
          ← Back to core menu
        </Link>
        <h1 className="vip-title">1v1 talks with toppers</h1>
        <p className="vip-note">These mentors are fictional. The replies stay on this device. This is a written 1v1 talk, not a live call.</p>
        <div className="topper-grid">
          {mentors.map((item) => (
            <article key={item.id} className={item.id === mentor.id && open ? "topper-card is-on" : "topper-card"}>
              <div className="topper-photo">
                <span>{item.result}</span>
              </div>
              <div className="topper-copy">
                <h2>{item.name}</h2>
                <p>{item.focus}</p>
                <button type="button" onClick={() => pick(item.id)}>
                  1v1 talk with toppers
                </button>
              </div>
            </article>
          ))}
        </div>
        {open ? (
          <div className="talk">
            {thread.map((line, index) => (
              <p key={`${line.from}-${index}`} className={line.from === "me" ? "is-me" : "is-them"}>
                {line.text}
              </p>
            ))}
            <div className="talk-asks">
              {mentor.replies.map((reply) => (
                <button key={reply.q} type="button" disabled={asked.includes(reply.q)} onClick={() => ask(reply.q, reply.a)}>
                  {reply.q}
                </button>
              ))}
            </div>
          </div>
        ) : null}
      </section>
    </main>
  );
}
