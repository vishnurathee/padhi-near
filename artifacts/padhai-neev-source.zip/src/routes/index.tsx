import { createFileRoute, Link } from "@tanstack/react-router";
import { Wires } from "@/components/wires";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div className="front">
      <Wires />
      <div className="front-shapes" aria-hidden="true">
        <span className="tri tri-a" />
        <span className="tri tri-b" />
        <span className="tri tri-c" />
        <span className="tri tri-d" />
        <span className="tri tri-e" />
      </div>
      <header className="front-bar">
        <Link to="/" className="front-logo">
          Padhaai <span>Neev</span>
        </Link>
      </header>
      <main className="front-main">
        <div className="front-hero">
          <h1>
            India's Most Trusted <span>Board Examination</span> Workspace
          </h1>
          <p>Welcome to Padhaai Neev VIP Hub. Select your current academic class below to open the resources.</p>
        </div>
        <div className="banner-row">
          <Link to="/c/$classId" params={{ classId: "10" }} search={{ tab: "home" }} className="banner-card class-10">
            <span className="banner-overlay" />
            <span className="banner-content">
              <span className="badge badge-orange">CBSE / STATE BOARDS</span>
              <span className="banner-title">CLASS 10</span>
              <span className="banner-copy">High school fundamentals, interactive sample papers and complete board preparation blueprints.</span>
              <span className="select-btn">Explore Neev</span>
            </span>
            <span className="geometric-shapes" aria-hidden="true">
              <span className="shape circle" />
              <span className="shape triangle" />
            </span>
          </Link>
          <Link to="/c/$classId" params={{ classId: "12" }} search={{ tab: "home" }} className="banner-card class-12">
            <span className="banner-overlay" />
            <span className="banner-content">
              <span className="badge badge-cyan">HIGHER SECONDARY</span>
              <span className="banner-title">CLASS 12</span>
              <span className="banner-copy">Advanced engineering, medical, commerce blueprints and high-yield standard mock sets.</span>
              <span className="select-btn">Explore Neev</span>
            </span>
            <span className="geometric-shapes" aria-hidden="true">
              <span className="shape wave" />
              <span className="shape grid-pattern" />
            </span>
          </Link>
        </div>
      </main>
    </div>
  );
}
