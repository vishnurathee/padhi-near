import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Quiz } from "@/components/quiz";
import { isClass, subjectsFor, type Question } from "@/lib/curriculum";
import { useProgress } from "@/lib/store";

export const Route = createFileRoute("/c/$classId/mock")({
  loader: ({ params }) => {
    if (!isClass(params.classId)) throw notFound();
    return { classId: params.classId };
  },
  component: MockPage,
});

function MockPage() {
  const { classId } = Route.useParams();
  const stream = useProgress((state) => state.stream);
  const [started, setStarted] = useState(false);
  const items = useMemo(() => {
    const pool: Question[] = [];
    for (const subject of subjectsFor(classId, stream)) {
      for (const chapter of subject.chapters) {
        for (const question of chapter.questions) pool.push(question);
      }
    }
    return pool.slice(0, 8);
  }, [classId, stream]);

  return (
    <main className="mx-auto w-full max-w-3xl px-4 pt-8 pb-28">
      <Link to="/c/$classId" params={{ classId }} search={{ tab: "home" }} className="text-sm text-muted">
        ← Class {classId}
      </Link>
      <h1 className="mt-4 text-3xl font-semibold">Mock test</h1>
      <p className="mt-2 text-muted">Eight mixed questions from the stream you picked. Change the stream on the class page.</p>
      {started ? (
        <div className="mt-6">
          <Quiz items={items} tone={classId === "12" ? "violet" : "cyan"} />
        </div>
      ) : (
        <button type="button" className="mt-8 min-h-12 rounded-xl bg-forest px-6 py-3 text-sm font-semibold text-bg" onClick={() => setStarted(true)}>
          Start the test
        </button>
      )}
    </main>
  );
}
