import { useState } from "react";
import { mathDiagnostics } from "@/data/math-diagnostics";

const letters = ["A", "B", "C", "D"];

export function MathQuizEngine() {
  const [index, setIndex] = useState(0);
  const [picks, setPicks] = useState<(number | null)[]>(() => mathDiagnostics.map(() => null));
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [finished, setFinished] = useState(false);

  const total = mathDiagnostics.length;
  const item = mathDiagnostics[index];
  const picked = picks[index];
  const score = picks.reduce<number>((sum, pick, pickIndex) => sum + (pick === mathDiagnostics[pickIndex]?.ans ? 1 : 0), 0);

  function choose(optionIndex: number) {
    if (picked !== null) return;
    setPicks((state) => state.map((value, valueIndex) => (valueIndex === index ? optionIndex : value)));
  }

  function toggle(node: string) {
    setOpen((state) => ({ ...state, [node]: !state[node] }));
  }

  function restart() {
    setIndex(0);
    setPicks(mathDiagnostics.map(() => null));
    setOpen({});
    setFinished(false);
  }

  if (finished) {
    const ratio = total === 0 ? 0 : score / total;
    const note = ratio >= 0.8 ? "Strong base. You are ready for the Class 10 triangle proofs." : ratio >= 0.5 ? "Fair. Open the hints and steps on the ones you missed, then try again." : "Revise the triangle theorems, then try again.";
    return (
      <div className="quiz-engine-wrapper">
        <div className="dashboard-view">
          <h2>Assessment report</h2>
          <div className="score-badge">
            {score} / {total}
          </div>
          <p className="eval-msg">{note}</p>
          <button type="button" className="nav-btn btn-primary retry-btn" onClick={restart}>
            Try again
          </button>
        </div>
      </div>
    );
  }

  if (!item) return null;

  return (
    <div className="quiz-engine-wrapper">
      <div className="quiz-top-bar">
        <span className="category-pill">{item.type}</span>
        <span className="counter-text">
          Question {index + 1} of {total}
        </span>
      </div>
      <div className="progress-bar-container">
        <div className="progress-fill" style={{ width: `${((index + 1) / total) * 100}%` }} />
      </div>
      <div className="question-segment">
        <h3>{item.q}</h3>
        <div className="cards-grid">
          {item.options.map((option, optionIndex) => {
            let cls = "option-card";
            if (picked !== null && optionIndex === item.ans) cls += " state-correct";
            else if (picked === optionIndex) cls += " state-wrong";
            return (
              <button key={option} type="button" className={cls} disabled={picked !== null} onClick={() => choose(optionIndex)}>
                {letters[optionIndex]}) {option}
              </button>
            );
          })}
        </div>
      </div>
      <div className="scaffold-accordion">
        <div className="scaffold-row">
          {(
            [
              ["hint", "Hint"],
              ["s1", "Step 1"],
              ["s2", "Step 2"],
              ["s3", "Step 3"],
              ["final", "Final answer"],
            ] as const
          ).map(([id, title]) => (
            <button key={id} type="button" className={open[id] ? "scaffold-header is-on" : "scaffold-header"} aria-expanded={!!open[id]} onClick={() => toggle(id)}>
              {title}
            </button>
          ))}
        </div>
        {open.hint ? <div className="scaffold-body">{item.hint}</div> : null}
        {open.s1 ? <div className="scaffold-body">{item.s1}</div> : null}
        {open.s2 ? <div className="scaffold-body">{item.s2}</div> : null}
        {open.s3 ? <div className="scaffold-body">{item.s3}</div> : null}
        {open.final ? <div className="scaffold-body final-box">{item.final}</div> : null}
      </div>
      <div className="wizard-nav">
        <button type="button" className="nav-btn" disabled={index === 0} onClick={() => { setIndex((value) => value - 1); setOpen({}); }}>
          Previous
        </button>
        <button
          type="button"
          className="nav-btn btn-primary"
          disabled={picked === null}
          onClick={() => {
            if (index >= total - 1) {
              setFinished(true);
              return;
            }
            setIndex((value) => value + 1);
            setOpen({});
          }}
        >
          {index >= total - 1 ? "See score" : "Next"}
        </button>
      </div>
    </div>
  );
}
